A HackBI project by Jonathan Wilson and Zavian Sider.

Run the BlackJackDriver to begin your gambling escapades.



Feel free to experiement with different betting amounts and starting cash.

Go for a long winstreak and practice your card counting along the way.